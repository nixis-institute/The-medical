from django.apps import AppConfig


class AppMadicalConfig(AppConfig):
    name = 'App_madical'
